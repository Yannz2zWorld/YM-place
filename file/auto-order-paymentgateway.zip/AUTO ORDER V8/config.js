module.exports = {

  //======= Setting Telegram =======//
  botToken: "token_bot_lu",
  ownerId: 1234567890,
  ownerName: "Yann",
  ownerWa: "6285xx",
  ownerUser: "@Yannz2z",
  botName: "AUTO ORDER YANN",
  startPhoto: "-",
  photosucces: "-", // foto send channel
  buyvpsfoto: "-", // foto send channel
  buydofoto: "-", // foto send channel
  buyvpsinfofoto: "-", // foto send channel Buy Vps
  startAudio: "-",
  startAudioCaption: "🛍 YANNZ AUTO ORDER 🛒",
  testimoniChannel: "@YannTestimOni", // channel lu isi
  ChannelOwner: "https://t.me/Yyyyan",
  GroupOwner: "https://t.me/Yyyyaan",
  resvps: "Hubungi Admin",
  resellerpanelLegal: "",
  buyubot: "Hubungi Admin",
  rulesdo: "-",
  succesdepootp: "-",
  succestrxotp: "-",
  resellerPanelbiasa: "Hubungi Admin",

  //======= Setting Pakasir =======//
  pakasir: {
    apikey: "-", // Ganti dengan API Key Pakasir Anda
    project: "Yann",   // Ganti dengan Project Slug Pakasir Anda
    mode: "api" // "api" atau "url" (Disarankan API untuk bot)
  },

  //======= Setting Penarikan (WD) =======//
  wd_balance: {
    bank_code: "DANA", // DANA, BCA, BRI, dll
    destination_number: ",085282426298",
    destination_name: "blm gw isi nma",
  },
  
  // --- Suntik Sosmed Setting (optional) ( FayuPedia )
    smm: {
        apiId: '6827', 
        apiKey: '-', 
        baseUrl: 'https://fayupedia.id/api' 
    },

  // --- Nokos Setting 
  RUMAHOTP: "rk-dev-GNqjRdA0QP85CzMixOjJLKsninJZ0LcL",
  UNTUNG_NOKOS: 1000,
  UNTUNG_DEPOSIT: 800,

  /// START WINGS
  tokeninstall: "yann",
  bash: "bash <(curl https://raw.githubusercontent.com/yann/gggimank/refs/heads/main/install.sh)",

  menuEffects: [
    "5104841245755180586",
    "5107584321108051014",
    "5159385139981059251",
    "5046509860389126442"
  ],

  premiumEffects: [
    "5103512349875603456",
    "5109987654321009876",
    "5198877665544332211"
  ],

  //======= Manual QRIS =======//
  manualQrisPhoto: "-", // qris manual lu

  //======= Setting VPS =======//
  ApiDO1: "", // ganti api do lu
  hargaVPS: {
    low: {
      "2c2": 5000,
      "4c2": 5500,
      "8c4": 6000,
      "16c4": 6000,
      "16c8": 7000
    },
    medium: {
      "2c2": 9000,
      "4c2": 9500,
      "8c4": 10000,
      "16c4": 11000,
      "16c8": 12000
    },
    high: {
      "2c2": 10000,
      "4c2": 11000,
      "8c4": 13000,
      "16c4": 14000,
      "16c8": 15000
    }
  },

  //======= GEMINI SETTING =======//
  USER_LIMIT: 3,
  GEMINI_API_KEY: "AIzaSyCSkRqdEvLLS8pCel_4Ir39-k6w-XtD6po",

  //======= Panel Setting =======//
  panel: {
    domain: "https://rexzzy-serverpublic.nezprivate.my.id/",
    apikey: "ptla_HKqy4nYH2llzItyFQ2zJASOeBGxAtuVq3tjxirWYETD",
    nestId: 5,
    eggId: 15,
    locationId: 1,
    startup: "npm start",
    image: "ghcr.io/parkervcp/yolks:nodejs_18"
  },

  reseller: {
    adminPanel: {
      monthly: 1100
    }
  },

  //======= Harga Panel =======//
  hargaPanel: {
    unlimited: 7000,
  }
};
